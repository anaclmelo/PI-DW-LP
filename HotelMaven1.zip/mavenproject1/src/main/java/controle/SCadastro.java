/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controle;

import DAOs.DAOCliente;
import entidades.Cliente;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author anaac
 */
@WebServlet(name = "SCadastro", urlPatterns = {"/SCadastro"})
public class SCadastro extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            String id = request.getParameter("id");
            String data = request.getParameter("data");
            String nome = request.getParameter("nome");
            String cpf = request.getParameter("cpf");
            String endereco = request.getParameter("endereco");
            String cidade = request.getParameter("cidade");
            String telefone = request.getParameter("telefone");
            String email = request.getParameter("email");
            
            DAOCliente controle = new DAOCliente();
            Date dt = controle.stringDate(data);
            
            Cliente cliente = new Cliente();
            
            cliente.setIdCliente(Integer.parseInt(id));
            cliente.setNome(nome);
            cliente.setDataNascimento(dt);
            cliente.setCpf(cpf);
            cliente.setEndereco(endereco);
            cliente.setCidade(cidade);
            cliente.setTelefone(telefone);
            cliente.setEmail(email);
            
            controle.inserir(cliente);
            
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet ServletCadastro</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>"+cliente.getIdCliente()+"</h1>");
            out.println("<h1>"+cpf+"</h1>");
            out.println("<h1>"+endereco+"</h1>");
            out.println("<h1>"+cidade+"</h1>");
            out.println("<h1>"+telefone+"</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
    
    
    
//    Integer id= controle.autoIdCliente();
//            
//    cliente.setIdCliente(id);
    
    
    
// * To change this license header, choose License Headers in Project Properties.
// * To change this template file, choose Tools | Templates
// * and open the template in the editor.
// */
//package c;
//
//import DAOs.DAOCliente;
//import entidades.Cliente;
//import java.io.IOException;
//import java.io.PrintWriter;
//import java.util.ArrayList;
//import java.util.Date;
//import java.util.List;
//import javax.servlet.ServletException;
//import javax.servlet.annotation.WebServlet;
//import javax.servlet.http.HttpServlet;
//import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpServletResponse;
//
///**
// *
// * @author anaac
// */
//@WebServlet(name = "ServletCadastro", urlPatterns = {"/ServletCadastro"})
//public class ServletCadastro extends HttpServlet {
//
//    /**
//     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
//     * methods.
//     *
//     * @param request servlet request
//     * @param response servlet response
//     * @throws ServletException if a servlet-specific error occurs
//     * @throws IOException if an I/O error occurs
//     */
//    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
//            throws ServletException, IOException {
//        response.setContentType("text/html;charset=UTF-8");
//        try (PrintWriter out = response.getWriter()) {
//            /* TODO output your page here. You may use following sample code. */
//            String idCliente = request.getParameter("idCliente");
//            String data = request.getParameter("data");
//            String nome = request.getParameter("nome");
//            String cpf = request.getParameter("cpf");
//            String endereco = request.getParameter("endereco");
//            String cidade = request.getParameter("cidade");
//            String telefone = request.getParameter("telefone");
//            
//            DAOCliente c = new DAOCliente();
//            Date dt = c.stringDate(data);
//            List<Cliente> dados = savePrint(idCliente, nome, cpf, dt, endereco, cidade, telefone);
//            String aux[];
//            aux = String.valueOf(dados).split(";");
//
//            out.println("<!DOCTYPE html>");
//            out.println("<html>");
//            out.println("<head>");
//            out.println("<title>Servlet Servlet</title>");
//            out.println("</head>");
//            out.println("<body>");
//            out.println("<h1>idCliente: " + aux[0].substring(1) + "</h1>");
//            out.println("<h1>nome: " + aux[1] + "</h1>");
//            out.println("<h1>cpf: " + aux[2] + "</h1>");
//            out.println("<h1>data de nascimento: " + aux[3] + "</h1>");
//            out.println("<h1>endereco: " + aux[4] + "</h1>");
//            out.println("<h1>cidade: " + aux[5] + "</h1>");
//            out.println("<h1>telefone: " + aux[6].substring(0, aux[3].length() - 1) + "</h1>");
//            out.println("</body>");
//            out.println("</html>");
//
//            
////            out.println("<!DOCTYPE html>");
////            out.println("<html>");
////            out.println("<head>");
////            out.println("<title>Servlet ServletCadastro</title>");            
////            out.println("</head>");
////            out.println("<body>");
////            out.println("<h1>"+idCliente+"</h1>");
////            out.println("<h1>"+data+"</h1>");
////            out.println("<h1>"+nome+"</h1>");
////            out.println("<h1>"+cpf+"</h1>");
////            out.println("<h1>"+endereco+"</h1>");
////            out.println("<h1>"+cidade+"</h1>");
////            out.println("<h1>"+telefone+"</h1>");
////            out.println("</body>");
////            out.println("</html>");
//        }
//    }
//
//    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
//    /**
//     * Handles the HTTP <code>GET</code> method.
//     *
//     * @param request servlet request
//     * @param response servlet response
//     * @throws ServletException if a servlet-specific error occurs
//     * @throws IOException if an I/O error occurs
//     */
//    @Override
//    protected void doGet(HttpServletRequest request, HttpServletResponse response)
//            throws ServletException, IOException {
//        processRequest(request, response);
//    }
//
//    /**
//     * Handles the HTTP <code>POST</code> method.
//     *
//     * @param request servlet request
//     * @param response servlet response
//     * @throws ServletException if a servlet-specific error occurs
//     * @throws IOException if an I/O error occurs
//     */
//    @Override
//    protected void doPost(HttpServletRequest request, HttpServletResponse response)
//            throws ServletException, IOException {
//        processRequest(request, response);
//    }
//
//    /**
//     * Returns a short description of the servlet.
//     *
//     * @return a String containing servlet description
//     */
//    @Override
//    public String getServletInfo() {
//        return "Short description";
//    }// </editor-fold
//
//    private List<Cliente> savePrint(String idCliente, String nome, String cpf, Date dt, String endereco, String cidade, String telefone) {
//        DAOCliente c = new DAOCliente();
//        Cliente cliente = new Cliente();
//
//        cliente.setIdCliente(Integer.valueOf(idCliente));
//        cliente.setNome(nome);
//        cliente.setDataNascimento(dt);
//        cliente.setCpf(cpf);
//        cliente.setEndereco(endereco);
//        cliente.setCidade(cidade);
//        cliente.setTelefone(telefone);
//        c.inserir(cliente);
// 
//        List<Cliente> dados = new ArrayList<>();
//        dados = c.listById(Integer.valueOf(idCliente));
//        System.out.println(dados);
//       
//        return dados;
//    }
//
//}
}
